package org.bouncycastle.crypto;

/**
 * Parameters for key/byte stream derivation classes
 */
public interface DerivationParameters
{
}

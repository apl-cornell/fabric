// You can redistribute this software and/or modify it under the terms of
// the Ozone Core License version 1 published by ozone-db.org.
//
// The original code and portions created by Thorsten Fiebig are
// Copyright (C) 2000-@year@ by Thorsten Fiebig. All rights reserved.
// Code portions created by SMB are
// Copyright (C) 1997-@year@ by SMB GmbH. All rights reserved.
//
// $Id$

import org.ozoneDB.DxLib.*;


public class OO7_AtomicPartImpl extends OO7_DesignObjectImpl implements OO7_AtomicPart {
    long theX;
    long theY;
    long theDocId;
    DxListBag theToConnections;
    DxListBag theFromConnections;
    OO7_CompositePart thePartOf;
    
    
    public OO7_AtomicPartImpl() {
        theToConnections = new DxListBag();
        theFromConnections = new DxListBag();
    }
    
    
    public void setX( long x ) {
        theX = x;
    } 
    
    
    public long x() {
        return theX;
    } 
    
    
    public void setY( long x ) {
        theY = x;
    } 
    
    
    public long y() {
        return theY;
    } 
    
    
    public void setDocId( long x ) {
        theDocId = x;
    } 
    
    
    public long docId() {
        return theDocId;
    } 
    
    
    public void addTo( OO7_Connection x ) {
        theToConnections.add( x );
    } 
    
    
    public DxBag to() {
        return theToConnections;
    } 
    
    
    public void addFrom( OO7_Connection x ) {
        theFromConnections.add( x );
    } 
    
    
    public DxBag from() {
        return theFromConnections;
    } 
    
    
    public void setPartOf( OO7_CompositePart x ) {
        thePartOf = x;
    } 
    
    
    public OO7_CompositePart partOf() {
        return thePartOf;
    } 
}

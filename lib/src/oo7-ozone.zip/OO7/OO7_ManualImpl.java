// You can redistribute this software and/or modify it under the terms of
// the Ozone Core License version 1 published by ozone-db.org.
//
// The original code and portions created by Thorsten Fiebig are
// Copyright (C) 2000-@year@ by Thorsten Fiebig. All rights reserved.
// Code portions created by SMB are
// Copyright (C) 1997-@year@ by SMB GmbH. All rights reserved.
//
// $Id$

import org.ozoneDB.OzoneObject;
import java.io.*;


public class OO7_ManualImpl extends OzoneObject implements OO7_Manual, Externalizable {
    
    String theTitle;
    long theId;
    String theText;
    OO7_Module theModule;
    
    
    public void setTitle( String x ) {
        theTitle = x;
    } 
    
    
    public String title() {
        return theTitle;
    } 
    
    
    public void setId( long x ) {
        theId = x;
    } 
    
    
    public long id() {
        return theId;
    } 
    
    
    public void setText( String x ) {
        theText = x;
    } 
    
    
    public String text() {
        return theText;
    } 
    
    
    public void setModule( OO7_Module x ) {
        theModule = x;
    } 
    
    
    public OO7_Module module() {
        return theModule;
    } 
    
    
    public void writeExternal( ObjectOutput out ) throws IOException {
        out.writeUTF( theTitle );
        out.writeLong( theId );
        out.writeUTF( theText );
        out.writeObject( theModule );
    } 
    
    
    public void readExternal( ObjectInput in ) throws IOException, ClassNotFoundException {
        theTitle = in.readUTF();
        theId = in.readLong();
        theText = in.readUTF();
        theModule = (OO7_Module)in.readObject();
    } 
    
}
